Mini CNC Plotter V3 by AverageEngg on Thingiverse: https://www.thingiverse.com/thing:6954397

Summary:
I built a Mini  CNC plotter V3 from 3D printed parts! This budget-friendly project is perfect for hobbyists, makers, and engineers looking to create a custom drawing machine. It consists of two 28byj-48 Stepper motors, one servo motor and 3D printed parts that provide movement in two axes. The 3D printed parts are designed in such a way that the whole machine become budget friendly, easy to build, compact, light in weight and looks cool. How to make Mini CNC Plotter V3https://youtu.be/hJhmfK4K_ZEGRBL 28byj-48 + Servo Motor uploading error fixhttps://youtu.be/mPPneh08FJg
